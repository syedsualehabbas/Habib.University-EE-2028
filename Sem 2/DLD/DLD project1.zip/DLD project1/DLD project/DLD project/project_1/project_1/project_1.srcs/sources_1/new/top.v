`timescale 1ns / 1ps
module top(
    input clk_100MHz,       // 100MHz on Basys 3
    input reset,            // btnC
    input up,               // btnU
    input down,             // btnD
    input left,             // btnL (onboard left button)
    input right,            // btnR (onboard right button)
    input ext_left,         // External left button (connected to JA3)
    input ext_right,        // External right button (connected to JA4)
    output hsync,           // to VGA connector
    output vsync,           // to VGA connector
    output [11:0] rgb      // to DAC, to VGA connector
    );
    
    // Debounced signals
    wire enable;
    wire w_reset, w_up, w_down;
    wire left_debounced, right_debounced;
    wire ext_left_debounced, ext_right_debounced;
    
    // VGA controller outputs
    wire w_video_on;
    wire [9:0] w_x, w_y;
    wire [3:0] digit_1s, digit_10s, digit_100s, digit_1000s;

    
    // Combined movement signals
    wire w_left, w_right;
    
    // Generate p_tick signal (25MHz pixel clock enable)
    reg [1:0] pixel_reg;
    wire p_tick;
    
    // RGB buffer signals
    reg  [11:0] rgb_reg;
    wire [11:0] rgb_next;
    wire [15:0] score_out;  // Changed to 16 bits to match pixel_gen
    reg [15:0] r_score_out;
    
    // 25MHz pixel tick generation
    always @(posedge clk_100MHz)
        pixel_reg <= pixel_reg + 1;
    assign p_tick = (pixel_reg == 0);
    
    // Debounce buttons individually
    btn_debounce dReset(.clk(clk_100MHz), .btn_in(reset), .btn_out(w_reset));
    btn_debounce dUp   (.clk(clk_100MHz), .btn_in(up),    .btn_out(w_up));
    btn_debounce dDown (.clk(clk_100MHz), .btn_in(down),  .btn_out(w_down));
    btn_debounce dLeft (.clk(clk_100MHz), .btn_in(left),  .btn_out(left_debounced));
    btn_debounce dRight(.clk(clk_100MHz), .btn_in(right), .btn_out(right_debounced));
    btn_debounce dExtLeft (.clk(clk_100MHz), .btn_in(ext_left),  .btn_out(ext_left_debounced));
    btn_debounce dExtRight(.clk(clk_100MHz), .btn_in(ext_right), .btn_out(ext_right_debounced));
    
    // Combine onboard and external buttons
    assign w_left = left_debounced | ext_left_debounced;
    assign w_right = right_debounced | ext_right_debounced;
    
    // Instantiate VGA controller
    vga_controller vga (
        .clk_100MHz(clk_100MHz),
        .reset(w_reset),
        .hsync(hsync),
        .vsync(vsync),
        .video_on(w_video_on),
        .x(w_x),
        .y(w_y)
    );
    
    new_binary_clock bin(
        .clk_100MHz(clk_100MHz),
        .reset(reset),
        .enable(enable),      
        .digit_1s(digit_1s),
        .digit_10s(digit_10s),
        .digit_100s(digit_100s),
        .digit_1000s(digit_1000s)
        );

    // Instantiate Pixel Generator
    pixel_gen pg(
        .clk(clk_100MHz),
        .reset(w_reset),
        .up(w_up),
        .down(w_down),
        .left(w_left),
        .right(w_right),
        .video_on(w_video_on),
        .p_tick(p_tick),    // Fixed signal name
        .digit_1s(digit_1s),
        .digit_10s(digit_10s),
        .digit_100s(digit_100s),
        .digit_1000s(digit_1000s),
        .x(w_x),
        .y(w_y),
        .rgb(rgb_next),
        .enable(enable)
    );
    
    // Score register with synchronous reset
    // RGB output buffer
    always @(posedge clk_100MHz) begin
        if (w_video_on)
            rgb_reg <= rgb_next;
        else
            rgb_reg <= 12'h000;  // Black when video is off
     end
            
    assign rgb = rgb_reg;
endmodule