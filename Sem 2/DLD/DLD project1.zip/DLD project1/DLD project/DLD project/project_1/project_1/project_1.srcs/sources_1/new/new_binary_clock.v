module new_binary_clock(
    input clk_100MHz,                   // sys clock
    input reset,                        // reset counter
    input enable,
    output tick_1Hz,                    // 1Hz output signal
    output [3:0] digit_1s, digit_10s,   // BCD outputs for 1s and 10s
    output [3:0] digit_100s, digit_1000s // BCD outputs for 100s and 1000s
    );
    
    // ********************************************************
    // create the 1Hz signal
    reg [13:0] h_score = 14'b0;
    reg [31:0] ctr_1Hz = 32'h0;
    reg r_1Hz = 1'b0;
    
    always @(posedge clk_100MHz or posedge reset)
        if(reset)
            ctr_1Hz <= 32'h0;
        else
            if(ctr_1Hz == 49_999_999) begin
                ctr_1Hz <= 32'h0;
                r_1Hz <= ~r_1Hz;
            end
            else
                ctr_1Hz <= ctr_1Hz + 1;
     
    // ********************************************************
    // regs for counter value
    reg [13:0] counter = 14'b0;   // 14 bits can represent up to 16383, enough for 0-9999
	
    // counter control
    always @(posedge tick_1Hz or posedge reset)
        if(reset | ~enable) begin
            if (counter > h_score)
                h_score <= counter;
            counter <= 14'b0;
        end 
        else begin 
            if(counter == 9999)
                counter <= 14'b0;
            else
                counter <= counter + 1;
        end 
                  
    // ********************************************************                
    
    wire [13:0] display_value;
    assign display_value = enable ? counter : h_score;
    
    // Calculate each BCD digit from the selected display value
    assign digit_1s    = display_value % 10;
    assign digit_10s   = (display_value / 10) % 10;
    assign digit_100s  = (display_value / 100) % 10;
    assign digit_1000s = (display_value / 1000) % 10;

     
    // 1Hz output            
    assign tick_1Hz = r_1Hz; 
            
endmodule