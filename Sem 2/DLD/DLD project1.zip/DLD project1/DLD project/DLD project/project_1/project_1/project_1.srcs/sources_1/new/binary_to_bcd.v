`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 04/16/2025 11:12:36 PM
// Design Name: 
// Module Name: binary_to_bcd
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module binary_to_bcd (
    input [15:0] binary,
    output reg [3:0] digit3, // Thousands
    output reg [3:0] digit2, // Hundreds
    output reg [3:0] digit1, // Tens
    output reg [3:0] digit0  // Ones
);
    integer i;
    reg [27:0] shift;

    always @* begin
        shift = 0;
        shift[15:0] = binary;

        for (i = 0; i < 16; i = i + 1) begin
            if (shift[19:16] >= 5)
                shift[19:16] = shift[19:16] + 3;
            if (shift[23:20] >= 5)
                shift[23:20] = shift[23:20] + 3;
            if (shift[27:24] >= 5)
                shift[27:24] = shift[27:24] + 3;

            shift = shift << 1;
        end

        digit3 = shift[27:24];
        digit2 = shift[23:20];
        digit1 = shift[19:16];
        digit0 = shift[15:12];
    end
endmodule

