`timescale 1ns / 1ps
module pixel_gen(
    input wire clk,
    input wire reset,
    input wire up, down, left, right,
    input wire [9:0] x, y,
    input wire video_on,
    input wire p_tick,
    input [3:0] digit_1s, digit_10s, digit_100s, digit_1000s,
    output reg [11:0] rgb,
    output reg enable
);
    // Game states
    localparam START_SCREEN = 2'b00;
    localparam GAME_PLAY = 2'b01;
    localparam COLLISION_DELAY = 2'b10;
    localparam GAME_OVER = 2'b11;
    
    // Display parameters
    localparam H_DISPLAY = 640;
    localparam V_DISPLAY = 480;
    localparam X_MAX = H_DISPLAY - 1;
    localparam Y_MAX = V_DISPLAY - 1;
    
    // Game area boundaries
    localparam GREEN_LEFT_BOUND = 120;
    localparam FOOTPATH_LEFT_RIGHT = 150;
    localparam ROAD_LEFT_BOUND = 150; 
    localparam ROAD_RIGHT_BOUND = H_DISPLAY - 150;
    localparam GREEN_RIGHT_BOUND = H_DISPLAY - 120;
    localparam ROAD_WIDTH = ROAD_RIGHT_BOUND - ROAD_LEFT_BOUND;
    
    // Lane markers
    localparam LANE_MARKER1 = ROAD_LEFT_BOUND + (ROAD_WIDTH / 3);
    localparam LANE_MARKER2 = ROAD_LEFT_BOUND + (2 * ROAD_WIDTH / 3);
    localparam LANE_PERIOD = 32;
    localparam LANE_DASH_HEIGHT = 8;
    
    // Colors
    localparam GREEN = 12'h0FF;
    localparam FOOTPATH_LEFT = 12'hFF0;
    localparam FOOTPATH_RIGHT = 12'hFFF;
    localparam ROAD = 12'h888;
    localparam LANEMARK = 12'hFFF;
    localparam START_SCREEN_COLOR = 12'h00A;
    localparam GAME_OVER_COLOR = 12'hF00;
    localparam OBSTACLE_COLOR = 12'hF00;
    
    // Frog parameters
    localparam FROG_SIZE = 64;
    localparam X_START = (H_DISPLAY / 2) - (FROG_SIZE / 2);
    localparam Y_START = V_DISPLAY - FROG_SIZE - 20;
    localparam FROG_VELOCITY = 5;
    localparam X_LEFT = FOOTPATH_LEFT_RIGHT - 30;
    localparam X_RIGHT = ROAD_RIGHT_BOUND - FROG_SIZE + 30;
    localparam Y_TOP = 68;
    localparam Y_BOTTOM = V_DISPLAY - FROG_SIZE;
    localparam Y_MARGIN = 8;
    localparam X_MARGIN = 18;
    
    // Obstacle parameters
    localparam OBSTACLE_WIDTH = 64;
    localparam OBSTACLE_HEIGHT = 40;
    localparam OBSTACLE1_BASE_INTERVAL = 100;
    localparam OBSTACLE2_BASE_INTERVAL = 140;
    localparam INTERVAL_VARIATION = 40;
    
    // Collision parameters
    localparam COLLISION_DELAY_TICKS = 120;
    
    // Game state registers
    reg [1:0] current_state, next_state;
    reg [15:0] game_tick_count;
    reg [7:0] collision_timer;
    reg collision_flag;
    
    // Frog position registers
    reg [9:0] x_frog_reg, y_frog_reg;
    reg [1:0] frog_select;
    
    // Road animation registers
    reg [7:0] road_offset;
    reg [2:0] road_counter;
    localparam ROAD_VELOCITY_DEN = 3;
    
    // Velocity control
    reg [7:0] dynamic_velocity;
    reg update_velocity_trigger;
    reg [9:0] velocity_update_counter;
    localparam VELOCITY_UPDATE_INTERVAL = 400;
    
    // Randomization (LFSR)
    reg [7:0] lfsr_main;
    reg [7:0] lfsr_secondary;
    reg [3:0] lfsr_update_counter;
    wire main_feedback = lfsr_main[7] ^ lfsr_main[6] ^ lfsr_main[3] ^ lfsr_main[1];
    wire secondary_feedback = lfsr_secondary[7] ^ lfsr_secondary[6] ^ lfsr_secondary[3] ^ lfsr_secondary[2];
    wire [7:0] random_val1 = lfsr_main[3:0] ^ lfsr_secondary[3:0];
    wire [7:0] random_val2 = lfsr_main[4:0] ^ lfsr_secondary[5:2];
    
    // Obstacle registers
    reg [9:0] obstacle1_x, obstacle1_y;
    reg obstacle1_active;
    reg [7:0] obstacle1_spawn_counter;
    reg [7:0] obstacle1_spawn_interval;
    reg obstacle1_spawn_trigger;
    
    reg [9:0] obstacle2_x, obstacle2_y;
    reg obstacle2_active;
    reg [7:0] obstacle2_spawn_counter;
    reg [7:0] obstacle2_spawn_interval;
    reg obstacle2_spawn_trigger;
    
    // Internal signals for calculations
    reg [9:0] x_frog_next_calc, y_frog_next_calc;
    reg collision_detected_this_frame;
    reg [11:0] rgb_next_calc;
    
    // Frame tick generation
    wire frame_start = (x == 0) && (y == 0) && video_on;
    reg frame_tick_reg, frame_tick_prev;
    wire frame_tick = frame_tick_reg;
    
    // Generate frame tick
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            frame_tick_reg <= 0;
            frame_tick_prev <= 0;
        end else begin
            frame_tick_prev <= frame_start;
            frame_tick_reg <= frame_start && !frame_tick_prev;
        end
    end
    
    // State machine next state logic
    wire start_pressed = up | down | left | right;
    always @* begin
        next_state = current_state;
        case (current_state)
            START_SCREEN:
                if (start_pressed && frame_tick)
                    next_state = GAME_PLAY;
            GAME_PLAY:
                if (collision_flag && frame_tick)
                    next_state = COLLISION_DELAY;
            COLLISION_DELAY:
                if (collision_timer >= COLLISION_DELAY_TICKS && frame_tick)
                    next_state = GAME_OVER;
            GAME_OVER:
                if (start_pressed && frame_tick)
                    next_state = START_SCREEN;
            default:
                next_state = START_SCREEN;
        endcase
    end
    
    // LFSR updates for randomization
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            lfsr_main <= 16'h39;
            lfsr_secondary <= 13'h12C;
            lfsr_update_counter <= 0;
        end else begin
            lfsr_update_counter <= lfsr_update_counter + 1;
            if (lfsr_update_counter == 4'hF) begin
                lfsr_main <= {lfsr_main[6:0], main_feedback};
                lfsr_secondary <= {lfsr_secondary[6:0], secondary_feedback};
            end
        end
    end
    
    // Main sequential logic for game state
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            // Initialize game state
            current_state <= START_SCREEN;
            x_frog_reg <= X_START;
            y_frog_reg <= Y_START;
            road_offset <= 0;
            road_counter <= 0;
            frog_select <= 0;
            game_tick_count <= 0;
            dynamic_velocity <= 1;
            collision_timer <= 0;
            collision_flag <= 0;
            velocity_update_counter <= 0;
            enable <= 0;
            
            // Initialize obstacle spawn system
            obstacle1_spawn_counter <= 0;
            obstacle1_spawn_interval <= OBSTACLE1_BASE_INTERVAL;
            obstacle1_spawn_trigger <= 0;
            obstacle2_spawn_counter <= 0;
            obstacle2_spawn_interval <= OBSTACLE2_BASE_INTERVAL;
            obstacle2_spawn_trigger <= 0;
        end else begin
            current_state <= next_state;
            
            if (frame_tick) begin
                // Default values
                x_frog_next_calc = x_frog_reg;
                y_frog_next_calc = y_frog_reg;
                collision_detected_this_frame = 0;
                update_velocity_trigger <= 0;
                obstacle1_spawn_trigger <= 0;
                obstacle2_spawn_trigger <= 0;
                
                // Handle state transitions
                if (current_state == START_SCREEN && next_state == GAME_PLAY) begin
                    // Reset game state
                    x_frog_reg <= X_START;
                    y_frog_reg <= Y_START;
                    road_offset <= 0;
                    road_counter <= 0;
                    frog_select <= 0;
                    game_tick_count <= 0;
                    dynamic_velocity <= 1;
                    collision_timer <= 0;
                    collision_flag <= 0;
                    velocity_update_counter <= 0;
                    enable <= 0; 
                    
                    // Reset obstacles with random intervals
                    obstacle1_spawn_counter <= 0;
                    obstacle1_spawn_interval <= OBSTACLE1_BASE_INTERVAL + (random_val1 % INTERVAL_VARIATION);
                    obstacle1_spawn_trigger <= 0;
                    obstacle2_spawn_counter <= 0;
                    obstacle2_spawn_interval <= OBSTACLE2_BASE_INTERVAL + (random_val2 % INTERVAL_VARIATION);
                    obstacle2_spawn_trigger <= 0;
                end
                else if (current_state == GAME_PLAY) begin
                    
                    if (~enable) begin
                        enable <= 1;
                    end
                    game_tick_count <= game_tick_count + 1;
                    
                    // Road animation
                    if (road_counter == ROAD_VELOCITY_DEN - 1) begin
                        road_offset <= road_offset + dynamic_velocity + 1;
                        road_counter <= 0;
                    end else begin
                        road_counter <= road_counter + 1;
                    end
                    
                    // Velocity update logic
                    if (velocity_update_counter == VELOCITY_UPDATE_INTERVAL - 1) begin
                        velocity_update_counter <= 0;
                        update_velocity_trigger <= 1;
                    end else begin
                        velocity_update_counter <= velocity_update_counter + 1;
                    end
                    
                    if (update_velocity_trigger && (dynamic_velocity < 20)) begin
                        dynamic_velocity <= dynamic_velocity + 1;
                    end
                    
                    // Frog movement based on input
                    if (up && (y_frog_reg >= FROG_VELOCITY) && ((y_frog_reg - FROG_VELOCITY) >= Y_TOP)) begin
                        y_frog_next_calc = y_frog_reg - FROG_VELOCITY;
                        frog_select <= 2'b00;
                    end else if (down && ((y_frog_reg + FROG_VELOCITY) <= Y_BOTTOM)) begin
                        y_frog_next_calc = y_frog_reg + FROG_VELOCITY;
                        frog_select <= 2'b01;
                    end else if (left && (x_frog_reg >= FROG_VELOCITY) && ((x_frog_reg - FROG_VELOCITY) >= X_LEFT)) begin
                        x_frog_next_calc = x_frog_reg - FROG_VELOCITY;
                        frog_select <= 2'b10;
                    end else if (right && ((x_frog_reg + FROG_VELOCITY) <= X_RIGHT)) begin
                        x_frog_next_calc = x_frog_reg + FROG_VELOCITY;
                        frog_select <= 2'b11;
                    end
                    
                    // Obstacle spawn logic
                    if (obstacle1_spawn_counter >= obstacle1_spawn_interval - 1) begin
                        obstacle1_spawn_counter <= 0;
                        obstacle1_spawn_trigger <= 1;
                        obstacle1_spawn_interval <= OBSTACLE1_BASE_INTERVAL + (random_val1 % INTERVAL_VARIATION);
                    end else begin
                        obstacle1_spawn_counter <= obstacle1_spawn_counter + 1;
                    end
                    
                    if (obstacle2_spawn_counter >= obstacle2_spawn_interval - 1) begin
                        obstacle2_spawn_counter <= 0;
                        obstacle2_spawn_trigger <= ((random_val2 & 8'h0F) < 8'h0A);
                        obstacle2_spawn_interval <= OBSTACLE2_BASE_INTERVAL + (random_val2 % INTERVAL_VARIATION);
                    end else begin
                        obstacle2_spawn_counter <= obstacle2_spawn_counter + 1;
                    end
                    
                    // Collision detection
                    if ((x_frog_next_calc < ROAD_LEFT_BOUND - 20) || (x_frog_next_calc + FROG_SIZE > 510)) begin
                        collision_detected_this_frame = 1;
                    end
                    
                    // Check collision with obstacle1
                    if (obstacle1_active) begin
                        if (x_frog_next_calc + X_MARGIN < obstacle1_x + OBSTACLE_WIDTH &&
                            x_frog_next_calc + FROG_SIZE - X_MARGIN > obstacle1_x &&
                            y_frog_next_calc + Y_MARGIN < obstacle1_y + OBSTACLE_HEIGHT &&
                            y_frog_next_calc + FROG_SIZE - Y_MARGIN > obstacle1_y) begin
                            collision_detected_this_frame = 1;
                        end
                    end
                    
                    // Check collision with obstacle2
                    if (obstacle2_active) begin
                        if (x_frog_next_calc + X_MARGIN < obstacle2_x + OBSTACLE_WIDTH &&
                            x_frog_next_calc + FROG_SIZE - X_MARGIN > obstacle2_x &&
                            y_frog_next_calc + Y_MARGIN < obstacle2_y + OBSTACLE_HEIGHT &&
                            y_frog_next_calc + FROG_SIZE - Y_MARGIN > obstacle2_y) begin
                            collision_detected_this_frame = 1;
                        end
                    end
                    
                    // Update frog position if no collision
                    if (!collision_detected_this_frame) begin
                        x_frog_reg <= x_frog_next_calc;
                        y_frog_reg <= y_frog_next_calc;
                    end
                    
                    collision_flag <= collision_detected_this_frame;
                end
                else if (current_state == COLLISION_DELAY) begin
                    enable <= 0;        
                    if (collision_timer < COLLISION_DELAY_TICKS) begin
                        collision_timer <= collision_timer + 1;
                    end
                end
                else if (current_state == GAME_OVER && next_state == START_SCREEN) begin
                    collision_timer <= 0;
                    collision_flag <= 0;
                    velocity_update_counter <= 0;
                    obstacle1_spawn_counter <= 0;
                    obstacle2_spawn_counter <= 0;
                end
            end
        end
    end
    
    // Obstacle1 logic
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            obstacle1_x <= ROAD_LEFT_BOUND + 50;
            obstacle1_y <= 0;
            obstacle1_active <= 0;
        end else if (frame_tick) begin
            if (current_state == START_SCREEN && next_state == GAME_PLAY) begin
                obstacle1_x <= ROAD_LEFT_BOUND + 50;
                obstacle1_y <= 0;
                obstacle1_active <= 0;
            end else if (current_state == GAME_PLAY) begin
                // Spawn logic
                if (!obstacle1_active && obstacle1_spawn_trigger) begin
                    obstacle1_active <= 1;
                    obstacle1_y <= 0;
                    
                    // Random X position
                    case (random_val1[2:0])
                        3'b000: obstacle1_x <= ROAD_LEFT_BOUND + (random_val2[3:0] * 4);
                        3'b001: obstacle1_x <= LANE_MARKER1 - OBSTACLE_WIDTH/2 - (random_val2[2:0] * 5);
                        3'b010: obstacle1_x <= LANE_MARKER1 + (random_val2[3:0] * 3);
                        3'b011: obstacle1_x <= LANE_MARKER2 - OBSTACLE_WIDTH/2 - (random_val2[2:0] * 4);
                        3'b100: obstacle1_x <= LANE_MARKER2 + (random_val2[3:0] * 3);
                        3'b101: obstacle1_x <= ROAD_RIGHT_BOUND - OBSTACLE_WIDTH - (random_val2[4:0]);
                        default: obstacle1_x <= ROAD_LEFT_BOUND + ((random_val1[7:3] * random_val2[4:0]) % (ROAD_WIDTH - OBSTACLE_WIDTH));
                    endcase
                end
                // Movement logic
                else if (obstacle1_active) begin
                    obstacle1_y <= obstacle1_y + dynamic_velocity + 1 + (random_val1[1:0]);
                    if (obstacle1_y >= V_DISPLAY) begin
                        obstacle1_active <= 0;
                    end
                end
            end
        end
    end
    
    // Obstacle2 logic
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            obstacle2_x <= ROAD_RIGHT_BOUND - OBSTACLE_WIDTH - 50;
            obstacle2_y <= 0;
            obstacle2_active <= 0;
        end else if (frame_tick) begin
            if (current_state == START_SCREEN && next_state == GAME_PLAY) begin
                obstacle2_x <= ROAD_RIGHT_BOUND - OBSTACLE_WIDTH - 50;
                obstacle2_y <= 0;
                obstacle2_active <= 0;
            end else if (current_state == GAME_PLAY) begin
                // Spawn logic
                if (!obstacle2_active && obstacle2_spawn_trigger) begin
                    obstacle2_active <= 1;
                    obstacle2_y <= 0;
                    
                    // Random X position with different algorithm
                    case (random_val2[4:2])
                        3'b000: obstacle2_x <= ROAD_LEFT_BOUND + 30 + (random_val1[5:2] * 3);
                        3'b001: obstacle2_x <= LANE_MARKER1 - OBSTACLE_WIDTH/2 - (random_val1[4:1] * 2);
                        3'b010: obstacle2_x <= (LANE_MARKER1 + random_val1[3:0] * 5) % (LANE_MARKER2 - OBSTACLE_WIDTH - 10);
                        3'b011: obstacle2_x <= (LANE_MARKER1 + LANE_MARKER2 - OBSTACLE_WIDTH)/2 + (random_val1[5:2] * 4) - 8;
                        3'b100: obstacle2_x <= LANE_MARKER2 + (random_val1[6:3] * 3);
                        3'b101: obstacle2_x <= ROAD_RIGHT_BOUND - OBSTACLE_WIDTH - 20 - (random_val1[5:0] % 30);
                        3'b110: obstacle2_x <= (LANE_MARKER2 + random_val1[4:0]) % (ROAD_RIGHT_BOUND - OBSTACLE_WIDTH - 10);
                        3'b111: obstacle2_x <= ROAD_LEFT_BOUND + ((random_val2[7:0] * random_val1[7:0]) % (ROAD_WIDTH - OBSTACLE_WIDTH));
                    endcase
                end
                // Movement logic
                else if (obstacle2_active) begin
                    obstacle2_y <= obstacle2_y + dynamic_velocity + (1 + random_val2[1:0]);
                    if (obstacle2_y >= V_DISPLAY) begin
                        obstacle2_active <= 0;
                        end
                end
            end
        end
    end
    
    // Display computation signals
    wire [9:0] x_frog_l = x_frog_reg;
    wire [9:0] y_frog_t = y_frog_reg;
    wire [9:0] x_frog_r = x_frog_l + FROG_SIZE - 1;
    wire [9:0] y_frog_b = y_frog_t + FROG_SIZE - 1;
    wire frog_on = (x >= x_frog_l) && (x <= x_frog_r) && (y >= y_frog_t) && (y <= y_frog_b);
    wire dash_on = (((y - road_offset) & (LANE_PERIOD - 1)) < LANE_DASH_HEIGHT);
    wire is_lane_marker1 = (x >= (LANE_MARKER1 - 2)) && (x < (LANE_MARKER1 + 2));
    wire is_lane_marker2 = (x >= (LANE_MARKER2 - 2)) && (x < (LANE_MARKER2 + 2));
    
    // Background color selection
    wire [11:0] bg_color =
        (x < GREEN_LEFT_BOUND) ? GREEN :
        (x < FOOTPATH_LEFT_RIGHT) ? FOOTPATH_LEFT :
        (x < ROAD_RIGHT_BOUND) ? 
            (((is_lane_marker1 || is_lane_marker2) && dash_on) ? LANEMARK : ROAD) :
        (x < GREEN_RIGHT_BOUND) ? FOOTPATH_RIGHT : GREEN;
    
    // Start screen image parameters
    localparam START_IMG_WIDTH = 128;
    localparam START_IMG_HEIGHT = 128;
    localparam START_IMG_X = (H_DISPLAY - START_IMG_WIDTH) / 2;
    localparam START_IMG_Y = (V_DISPLAY - START_IMG_HEIGHT) / 2;
    wire start_img_on = (x >= START_IMG_X) && (x <= START_IMG_X + START_IMG_WIDTH - 1) &&
                       (y >= START_IMG_Y) && (y <= START_IMG_Y + START_IMG_HEIGHT - 1);
    wire [6:0] start_rom_col = x - START_IMG_X;
    wire [6:0] start_rom_row = y - START_IMG_Y;
    wire [11:0] start_rom_color;
    frog_up_rom rom_start(.clk(clk), .row(start_rom_row), .col(start_rom_col), .color_data(start_rom_color));
    localparam CHAR_WIDTH = 16;           // Double width for larger font
    localparam CHAR_HEIGHT = 32;          // Double height for larger font
    localparam TEXT_LENGTH = 10;          // Number of characters in "START GAME"
    localparam TEXT_TOTAL_WIDTH = TEXT_LENGTH * CHAR_WIDTH;
    localparam TEXT_X_START = (H_DISPLAY - TEXT_TOTAL_WIDTH) / 2; // Center horizontally
    localparam TEXT_Y_POS = START_IMG_Y + START_IMG_HEIGHT + 30;  // Below the frog image
    localparam TEXT_COLOR = 12'hFFF;      // White text
    
// Text content function
function [7:0] get_char_code;
    input [4:0] index;
    begin
        case(index)
            5'd0: get_char_code = 8'h53; // S
            5'd1: get_char_code = 8'h54; // T
            5'd2: get_char_code = 8'h41; // A
            5'd3: get_char_code = 8'h52; // R
            5'd4: get_char_code = 8'h54; // T
            5'd5: get_char_code = 8'h20; // space
            5'd6: get_char_code = 8'h47; // G
            5'd7: get_char_code = 8'h41; // A
            5'd8: get_char_code = 8'h4D; // M
            5'd9: get_char_code = 8'h45; // E
            default: get_char_code = 8'h20; // space
        endcase
    end
endfunction



// ROM connections
wire [10:0] start_char_addr;
wire [7:0] char_data;
reg [4:0] char_index;

ascii_rom char_rom(
        .clk(clk),
        .addr(start_char_addr),
        .data(char_data)
    );

// Text area detection
wire text_on = (x >= TEXT_X_START && x < TEXT_X_START + TEXT_LENGTH*CHAR_WIDTH &&
               y >= TEXT_Y_POS && y < TEXT_Y_POS + CHAR_HEIGHT);

// Character index calculation
always @* begin
    if (text_on) begin
        char_index = (x - TEXT_X_START) / CHAR_WIDTH;
    end else begin
        char_index = 0;
    end
end

// Map to original font coordinates with scaling
wire [3:0] char_row = (y - TEXT_Y_POS) >> 1; // Divide by 2 for scaling
wire [2:0] char_col = (x - TEXT_X_START - char_index * CHAR_WIDTH) >> 1; // Divide by 2

// ROM address calculation
assign start_char_addr = {get_char_code(char_index), char_row[3:0]};

// Determine if current pixel should be lit
wire text_bit = text_on & char_data[7-char_col];

    
    
    // Frog ROM signals
    wire [5:0] rom_row = y - y_frog_t;
    wire [5:0] rom_col = x - x_frog_l;
    wire [11:0] rom_data_up;
    frog_up_rom rom_up(.clk(clk), .row(rom_row), .col(rom_col), .color_data(rom_data_up));
    wire [11:0] frog_rom_color = rom_data_up;
    
    // Game over image parameters
    // Game over image parameters
        localparam GAME_OVER_IMG_WIDTH = 128;
        localparam GAME_OVER_IMG_HEIGHT = 128;
        localparam GAME_OVER_IMG_X = (H_DISPLAY - GAME_OVER_IMG_WIDTH) / 2;
        localparam GAME_OVER_IMG_Y = (V_DISPLAY - GAME_OVER_IMG_HEIGHT) / 2;
        wire gameover_img_on = (x >= GAME_OVER_IMG_X) && (x <= GAME_OVER_IMG_X + GAME_OVER_IMG_WIDTH - 1) &&
                              (y >= GAME_OVER_IMG_Y) && (y <= GAME_OVER_IMG_Y + GAME_OVER_IMG_HEIGHT - 1);
        wire [6:0] gameover_rom_col = x - GAME_OVER_IMG_X;
        wire [6:0] gameover_rom_row = y - GAME_OVER_IMG_Y;
        wire [11:0] gameover_rom_color;
        frog_up_rom rom_gameover(.clk(clk), .row(gameover_rom_row), .col(gameover_rom_col), .color_data(gameover_rom_color));
        
        // Game Over text parameters
        localparam GAMEOVER_TEXT_LENGTH = 9;  // Number of characters in "GAME OVER"
        localparam GAMEOVER_TEXT_TOTAL_WIDTH = GAMEOVER_TEXT_LENGTH * CHAR_WIDTH;
        localparam GAMEOVER_TEXT_X_START = (H_DISPLAY - GAMEOVER_TEXT_TOTAL_WIDTH) / 2; // Center horizontally
        localparam GAMEOVER_TEXT_Y_POS = GAME_OVER_IMG_Y + GAME_OVER_IMG_HEIGHT + 30;  // Below the frog image
        localparam GAMEOVER_TEXT_COLOR = 12'hFFF;  // White text
        
        // Game Over text content function
        function [7:0] get_gameover_char_code;
            input [3:0] index;
            begin
                case(index)
                    4'd0: get_gameover_char_code = 8'h47; // G
                    4'd1: get_gameover_char_code = 8'h41; // A
                    4'd2: get_gameover_char_code = 8'h4D; // M
                    4'd3: get_gameover_char_code = 8'h45; // E
                    4'd4: get_gameover_char_code = 8'h20; // space
                    4'd5: get_gameover_char_code = 8'h4F; // O
                    4'd6: get_gameover_char_code = 8'h56; // V
                    4'd7: get_gameover_char_code = 8'h45; // E
                    4'd8: get_gameover_char_code = 8'h52; // R
                    default: get_gameover_char_code = 8'h20; // space
                endcase
            end
        endfunction
        
        // ROM connections
        wire [10:0] gameover_char_addr;
        wire [7:0] gameover_char_data;
        reg [3:0] gameover_char_index;
        ascii_rom gameover_char_rom(
            .clk(clk),
            .addr(gameover_char_addr),
            .data(gameover_char_data)
        );
        
        // Game Over text area detection
        wire gameover_text_on = (x >= GAMEOVER_TEXT_X_START && x < GAMEOVER_TEXT_X_START + GAMEOVER_TEXT_LENGTH*CHAR_WIDTH &&
                               y >= GAMEOVER_TEXT_Y_POS && y < GAMEOVER_TEXT_Y_POS + CHAR_HEIGHT);
        
        // Character index calculation
        always @* begin
            if (gameover_text_on) begin
                gameover_char_index = (x - GAMEOVER_TEXT_X_START) / CHAR_WIDTH;
            end else begin
                gameover_char_index = 0;
            end
        end
        
        // Map to original font coordinates with scaling
        wire [3:0] gameover_char_row = (y - GAMEOVER_TEXT_Y_POS) >> 1; // Divide by 2 for scaling
        wire [2:0] gameover_char_col = (x - GAMEOVER_TEXT_X_START - gameover_char_index * CHAR_WIDTH) >> 1; // Divide by 2
        
        // ROM address calculation
        assign gameover_char_addr = {get_gameover_char_code(gameover_char_index), gameover_char_row[3:0]};
        
        // Determine if current pixel should be lit
        wire gameover_text_bit = gameover_text_on & gameover_char_data[7-gameover_char_col];
        
        
    localparam HS_TEXT_LENGTH = 7;  // "HS:" + 4 digits
    localparam HS_TEXT_X_START = (H_DISPLAY - HS_TEXT_LENGTH * CHAR_WIDTH) / 2;
    localparam HS_TEXT_Y_POS = GAMEOVER_TEXT_Y_POS + CHAR_HEIGHT + 20;  // Below game over text
    localparam HS_TEXT_COLOR = 12'hFFF;  // White text
    
    function [7:0] get_highscore_char_code;
        input [3:0] index;
        begin
            case(index)
                4'd0: get_highscore_char_code = 8'h48; // H
                4'd1: get_highscore_char_code = 8'h53; // S
                4'd2: get_highscore_char_code = 8'h3A; // :
                4'd3: get_highscore_char_code = {3'b011, digit_1000s}; // 1000s digit
                4'd4: get_highscore_char_code = {3'b011, digit_100s};  // 100s digit
                4'd5: get_highscore_char_code = {3'b011, digit_10s};   // 10s digit
                4'd6: get_highscore_char_code = {3'b011, digit_1s};    // 1s digit
                default: get_highscore_char_code = 8'h20; // space
            endcase
        end
    endfunction
       
    wire [10:0] highscore_char_addr;
    wire [7:0] highscore_char_data;
    reg [3:0] highscore_char_index;
    
    // 4. Add this to connect the high score text ROM:
    clock_digit_rom highscore_char_rom(
        .clk(clk),
        .addr(highscore_char_addr),
        .data(highscore_char_data)
    );
    
    wire highscore_text_on = (x >= HS_TEXT_X_START && x < HS_TEXT_X_START + HS_TEXT_LENGTH*CHAR_WIDTH &&
                       y >= HS_TEXT_Y_POS && y < HS_TEXT_Y_POS + CHAR_HEIGHT);
                       
    always @* begin
        if (highscore_text_on) begin
            highscore_char_index = (x - HS_TEXT_X_START) / CHAR_WIDTH;
        end else begin
            highscore_char_index = 0;
        end
    end
    
    wire [3:0] highscore_char_row = (y - HS_TEXT_Y_POS) >> 1; // Divide by 2 for scaling
    wire [2:0] highscore_char_col = (x - HS_TEXT_X_START - highscore_char_index * CHAR_WIDTH) >> 1;

    assign highscore_char_addr = {get_highscore_char_code(highscore_char_index), highscore_char_row[3:0]};
    
    wire highscore_text_bit = highscore_text_on & highscore_char_data[7-highscore_char_col];

        // 1000s Digit section = 16 x 32
    localparam D1000_X_L = 16;
    localparam D1000_X_R = 31;
    localparam D1000_Y_T = 16;
    localparam D1000_Y_B = 47;
    
    // 100s Digit section = 16 x 32
    localparam D100_X_L = 32;
    localparam D100_X_R = 47;
    localparam D100_Y_T = 16;
    localparam D100_Y_B = 47;
    
    // 10s Digit section = 16 x 32
    localparam D10_X_L = 48;
    localparam D10_X_R = 63;
    localparam D10_Y_T = 16;
    localparam D10_Y_B = 47;
    
    // 1s Digit section = 16 x 32
    localparam D1_X_L = 64;
    localparam D1_X_R = 79;
    localparam D1_Y_T = 16;
    localparam D1_Y_B = 47;
    
    // Object Status Signals
    wire D1000_on, D100_on, D10_on, D1_on;
    
    // ROM Interface Signals
    wire [10:0] rom_addr;
    reg [6:0] char_addr;   // 3'b011 + BCD value of digit
    wire [6:0] char_addr_d1000, char_addr_d100, char_addr_d10, char_addr_d1;
    reg [3:0] row_addr;    // row address of digit
    wire [3:0] row_addr_d1000, row_addr_d100, row_addr_d10, row_addr_d1;
    reg [2:0] bit_addr;    // column address of rom data
    wire [2:0] bit_addr_d1000, bit_addr_d100, bit_addr_d10, bit_addr_d1;
    wire [7:0] digit_word;  // data from rom
    wire digit_bit;
    
    // Digit addressing - fixed scaling for proper display
    assign char_addr_d1000 = {3'b011, digit_1000s};
    assign row_addr_d1000 = (y - D1000_Y_T) >> 1;   // Map y-coordinate to ROM row address
    assign bit_addr_d1000 = (x - D1000_X_L) >> 1;   // Map x-coordinate to bit position
    
    assign char_addr_d100 = {3'b011, digit_100s};
    assign row_addr_d100 = (y - D100_Y_T) >> 1;     // Map y-coordinate to ROM row address
    assign bit_addr_d100 = (x - D100_X_L) >> 1;     // Map x-coordinate to bit position
    
    assign char_addr_d10 = {3'b011, digit_10s};
    assign row_addr_d10 = (y - D10_Y_T) >> 1;       // Map y-coordinate to ROM row address
    assign bit_addr_d10 = (x - D10_X_L) >> 1;       // Map x-coordinate to bit position
    
    assign char_addr_d1 = {3'b011, digit_1s};
    assign row_addr_d1 = (y - D1_Y_T) >> 1;         // Map y-coordinate to ROM row address
    assign bit_addr_d1 = (x - D1_X_L) >> 1;         // Map x-coordinate to bit position
    
    // Instantiate digit rom
    clock_digit_rom cdr(.clk(clk), .addr(rom_addr), .data(digit_word));
    
    // Digit sections assert signals
    assign D1000_on = (D1000_X_L <= x) && (x <= D1000_X_R) &&
                      (D1000_Y_T <= y) && (y <= D1000_Y_B);
    assign D100_on =  (D100_X_L <= x) && (x <= D100_X_R) &&
                      (D100_Y_T <= y) && (y <= D100_Y_B);
    assign D10_on =   (D10_X_L <= x) && (x <= D10_X_R) &&
                      (D10_Y_T <= y) && (y <= D10_Y_B);
    assign D1_on =    (D1_X_L <= x) && (x <= D1_X_R) &&
                      (D1_Y_T <= y) && (y <= D1_Y_B);
                          
    // Mux for ROM Addresses and RGB   
    // ROM Interface    
    assign rom_addr = {char_addr, row_addr};
    assign digit_bit = digit_word[~bit_addr];
    
    // Obstacle display signals
    wire obstacle1_on = obstacle1_active &&
                       (x >= obstacle1_x) && (x < obstacle1_x + OBSTACLE_WIDTH) &&
                       (y >= obstacle1_y) && (y < obstacle1_y + OBSTACLE_HEIGHT);
    wire obstacle2_on = obstacle2_active &&
                       (x >= obstacle2_x) && (x < obstacle2_x + OBSTACLE_WIDTH) &&
                       (y >= obstacle2_y) && (y < obstacle2_y + OBSTACLE_HEIGHT);
    
    // Pixel generation logic 
    always @* begin
        rgb_next_calc = 12'hF0F; // Default color
        
        if (~video_on) begin
            rgb_next_calc = 12'h000; // Black when video is off
        end else begin
            case (current_state)
                START_SCREEN: begin
                // Background
                 rgb_next_calc = START_SCREEN_COLOR;
                 
                 // Frog image
                 if (start_img_on) begin
                     rgb_next_calc = (start_rom_color == 12'hFFF) ? START_SCREEN_COLOR : start_rom_color;
                 end
                 
                 
                 // Draw text last (highest priority)
                 if (text_bit) begin
                     rgb_next_calc = TEXT_COLOR;
                 end
                 
                 if (highscore_text_bit) begin
                        rgb_next_calc = HS_TEXT_COLOR;
                    end
              
             end
                
                GAME_PLAY, COLLISION_DELAY: begin
                    // Background
                    rgb_next_calc = bg_color;
                   
                if(D1000_on) begin
                    char_addr = char_addr_d1000;
                    row_addr = row_addr_d1000;
                    bit_addr = bit_addr_d1000;
                    if(digit_bit)
                     rgb_next_calc = TEXT_COLOR;
                end
                else if(D100_on) begin
                    char_addr = char_addr_d100;
                    row_addr = row_addr_d100;
                    bit_addr = bit_addr_d100;
                    if(digit_bit)
                     rgb_next_calc = TEXT_COLOR;
                end
                else if(D10_on) begin
                    char_addr = char_addr_d10;
                    row_addr = row_addr_d10;
                    bit_addr = bit_addr_d10;
                    if(digit_bit)
                     rgb_next_calc = TEXT_COLOR;
                end
                else if(D1_on) begin
                    char_addr = char_addr_d1;
                    row_addr = row_addr_d1;
                    bit_addr = bit_addr_d1;
                    if(digit_bit)
                     rgb_next_calc = TEXT_COLOR;
                end
   
                    
                    // Obstacles
                    if (obstacle1_on) begin
                        rgb_next_calc = OBSTACLE_COLOR;
                    end
                    
                    if (obstacle2_on) begin
                        rgb_next_calc = OBSTACLE_COLOR;
                    end
                    
                    // Frog (highest priority)
                    if (frog_on) begin
                        rgb_next_calc = (frog_rom_color == 12'hFFF) ? rgb_next_calc : frog_rom_color;
                    end
                end
                
                GAME_OVER: begin
                     rgb_next_calc = GAME_OVER_COLOR;
                     
                    if (highscore_text_bit) begin
                        rgb_next_calc = HS_TEXT_COLOR;
                    end
                    if (gameover_img_on) begin
                        rgb_next_calc = (gameover_rom_color == 12'hFFF) ? GAME_OVER_COLOR : gameover_rom_color;
                    end
                                     if (gameover_text_bit) begin
                     rgb_next_calc = TEXT_COLOR;
                    end
                end
                
                default: rgb_next_calc = 12'hF0F;
            endcase
        end
    end
    
    // Final RGB output register
    always @(posedge clk) begin
        rgb <= rgb_next_calc;
    end
endmodule
