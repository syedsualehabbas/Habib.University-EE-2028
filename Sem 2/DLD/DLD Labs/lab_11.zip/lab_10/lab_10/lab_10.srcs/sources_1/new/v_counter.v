`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 03/24/2025 12:50:19 PM
// Design Name: 
// Module Name: v_counter
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module v_counter(clk, enable_v, v_count);
input clk; // input clk taken
input enable_v; // input enable_v taken
output [9:0] v_count; // output v_count of 10-bit
reg [9:0] v_count; 
initial v_count = 0; // initial value of v_count is 0
always @(posedge clk)
begin
if ((enable_v ) &(v_count<524))
v_count <= v_count+1;
else if (enable_v )
v_count<=0; // non-blocking
end
endmodule
