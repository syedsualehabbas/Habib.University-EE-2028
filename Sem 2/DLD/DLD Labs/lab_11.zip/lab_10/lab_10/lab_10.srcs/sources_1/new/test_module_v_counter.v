`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 03/24/2025 01:03:28 PM
// Design Name: 
// Module Name: test_module_v_counter
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module test_bench_v_counter();
reg clk; // clk of 1-bit
reg enable_v; // enable_v of 1-bit
wire [9:0] v_count; // v_count of 10-bit 
v_counter vcl(.clk(clk),.enable_v(enable_v),.v_count(v_count)); // Call v_counter module
initial
clk = 1'b0; // initialize clk value
always
#5 clk = ~clk; // changes clk value after 5 time-unit until finish.
initial
enable_v = 1'b0;
always
begin
#10 enable_v = ~enable_v; // Toggle enable_v continuously in 0 to 1 after 10 time-unit until finish.
end
initial
#200 $finish; // finish after 200 time-unit.
endmodule


