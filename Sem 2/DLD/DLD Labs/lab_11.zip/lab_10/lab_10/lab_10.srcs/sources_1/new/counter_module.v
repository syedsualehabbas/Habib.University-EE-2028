// Code your design here                                                
module h_counter(clk,count, trig_v);
input clk; // input clk taken
output [9:0] count; // output count of 10-bit
output trig_v; // output trig_v taken
reg [9:0] count;
reg trig_v;
initial count = 0; // initial value of count is 0
initial trig_v = 0; // initial value of trig_v is 0
always @ (posedge clk)
begin
if (count <= 799) // if count <= 799, else trig_v = 1
begin
    count <= count + 1;
    trig_v = 0;
end
else
begin
trig_v = 1; 
count = 0;
end
end endmodule
