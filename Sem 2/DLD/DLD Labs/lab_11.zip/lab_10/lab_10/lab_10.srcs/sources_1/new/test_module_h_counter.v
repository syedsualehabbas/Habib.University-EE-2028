`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 03/24/2025 12:24:39 PM
// Design Name: 
// Module Name: test_module_h_counter
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module test_module_h_counter();
reg clk; // clk of 1-bit
wire [9:0] count; // count of 10-bit
wire trig_v; // trig_v of 1-bit
h_counter c1(.clk(clk),.count(count), .trig_v(trig_v)); // call h_counter module
initial
clk = 1'b0; // initial value of clk is 0
always
#0.5 clk = ~clk; // clk value changes after .5 time-unit
initial
#2000 $finish;
endmodule
