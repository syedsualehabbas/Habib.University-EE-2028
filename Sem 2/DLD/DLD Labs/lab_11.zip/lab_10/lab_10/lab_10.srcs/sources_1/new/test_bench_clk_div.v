`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 03/24/2025 01:48:25 PM
// Design Name: 
// Module Name: test_bench_clk_div
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module test_bench_clk_div();
reg clk;
wire clk_d;
clk_div cl(.clk(clk), .clk_d(clk_d)); // module call
initial
clk = 1'b0; // initial value of clk = 0
always
#5 clk = ~clk; // value changes after 5 time-unit
initial
#200 $finish; // finish after 200 time-unit
endmodule
