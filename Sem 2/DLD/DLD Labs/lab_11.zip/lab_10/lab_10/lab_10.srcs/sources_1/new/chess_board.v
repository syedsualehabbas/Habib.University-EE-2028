`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 04/09/2025 12:59:33 PM
// Design Name: 
// Module Name: chess_board
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module pixel_chess(
input clk_d, // pixel clock
input [9:0] pixel_x,
input [9:0] pixel_y,
input video_on,
output reg [3:0] red = 0,
output reg [3:0] green = 0,
output reg [3:0] blue = 0
);

always @(posedge clk_d)
begin
if ((pixel_x == 0) || (pixel_x == 640) || (pixel_y == 0) || (pixel_y == 480))
begin
red <= 4'hF; green <= 4'hF; blue <= 4'hF; // White border
end
else if (video_on)
begin
if (((pixel_x / 80) + (pixel_y / 60)) % 2 == 0) // Calculate which square the pixel is in
begin
red <= 4'hF; green <= 4'hF; blue <= 4'hF; // White square
end
else
begin
red <= 4'h0; green <= 4'h0; blue <= 4'h0; // Black square
end
end
else
begin
red <= 4'h0; green <= 4'h0; blue <= 4'h0;
end
end
endmodule

