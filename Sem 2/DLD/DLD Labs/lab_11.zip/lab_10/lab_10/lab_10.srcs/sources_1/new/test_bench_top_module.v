`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 03/24/2025 02:14:42 PM
// Design Name: 
// Module Name: test_bench_top_module
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module test_bench_top_module();
reg clk;
wire h_sync;
wire v_sync;
wire [3: 0] red;
wire [3: 0] green;
wire [3: 0] blue;
top_module tpm(.clk(clk), .h_sync(h_sync), .v_sync(v_sync), .red(red), .green(green), .blue(blue)); // module call
initial
clk = 1'b0; // initial value of clk = 0
always
#5 clk = ~clk; // value changes after 5 time-unit
initial
#200 $finish; // finish after 200 time-unit
endmodule
