`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 03/24/2025 02:09:04 PM
// Design Name: 
// Module Name: top_module
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module top_module(clk, h_sync, v_sync, red, green, blue);
input clk;
output h_sync;
output v_sync;
output [3: 0] red;
output [3: 0] green;
output [3: 0] blue;
wire clk_d, trig_v, video_on;
wire [9: 0] x_loc;
wire [9: 0] y_loc;
wire [9: 0] h_count;
wire [9: 0] v_count;
clk_div clkd(clk, clk_d); // call clk_div module
h_counter hcnt(clk_d, h_count, trig_v); // call h_counter module
v_counter vcnt(clk_d, trig_v, v_count); // call v_counter module
vga_sync vgas(h_count, v_count, h_sync, v_sync, video_on, x_loc, y_loc); // call vga_sync module
pixel_gen pg(clk_d, x_loc, y_loc, video_on, red, green, blue);
endmodule
