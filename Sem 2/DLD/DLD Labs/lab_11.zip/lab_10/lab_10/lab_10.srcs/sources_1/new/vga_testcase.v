`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 04/07/2025 11:57:31 PM
// Design Name: 
// Module Name: vga_testcase
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module vga_testcase();
reg clk;
wire clk_d;
wire h_sync;
wire v_sync;
wire video_on; // active area
wire [9:0] x_loc; // current pixel x- location
wire [9:0] y_loc; // current pixel y-location
wire trig_v;
wire [9: 0] h_count;
wire [9: 0] v_count;
clk_div clkd(clk, clk_d); // call clk_div module
h_counter hcnt(clk_d, h_count, trig_v); // call h_counter module
v_counter vcnt(clk_d, trig_v, v_count); // call v_counter module
vga_sync vgas(h_count, v_count, h_sync, v_sync, video_on, x_loc, y_loc);
initial
clk = 1'b0; // initial value of clk = 0
always
#5 clk = ~clk; // value changes after 5 time-unit
initial
#200 $finish; // finish after 200 time-unit
endmodule
