`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 03/26/2025 10:21:10 AM
// Design Name: 
// Module Name: pixel_gen
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module pixel_gen(
input clk_d, // pixel clock
input [9:0] pixel_x,
input [9:0] pixel_y,
input video_on,
output reg [3:0] red=0,
output reg [3:0] green=0,
output reg [3:0] blue=0
);
always @(posedge clk_d)
begin
if ((pixel_x ==0) || (pixel_x ==640) || (pixel_y ==0) || (pixel_y==480))
begin
red <= 4'hF; green <= 4'hF; blue <= 4'hF;
end
else
begin
red <= video_on ? (pixel_y > 240 ? 4'hF : 4'h0) : (4'h0);
green <= video_on ? (pixel_y > 240 ? 4'h0 : 4'hF) : (4'h0);
blue <= 4'h0;
end
end
endmodule
