`timescale 1ns / 1ps


module v_counter(
input clk,
input v_enable,
output reg [9:0] v_count
    );
initial begin
v_count = 10'b000_000_000_0;
 
end

always @(posedge clk) begin 
    if (v_count == 10'b100_001_110_0) begin  
        v_count <= 10'b000_000_000_0; 
    end 
    else if (v_enable == 1) begin 
    v_count <= v_count + 1'b1;
    end
    else 
    begin
        
    end
end

endmodule