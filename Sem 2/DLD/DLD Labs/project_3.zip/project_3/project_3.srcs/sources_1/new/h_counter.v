module h_counter(
    output reg [9:0] count,
    output reg trig_v,
    input clk
);

initial begin
    count = 10'b000_000_000_0;
    trig_v = 0;
end

always @(posedge clk) begin 
    if (count == 10'b1100011110) begin  // 799 in binary
        trig_v <= 1;  
        count <= count + 1'b1;  // Reset count
    end 
    else if (count == 10'b1100011111) begin  // 799 in binary
        trig_v <= 0; 
        count <= 10'b000_000_000_0;  // Reset count
    end 
    else begin
        count <= count + 1'b1;
        trig_v <= 0; 
    end
end

endmodule
