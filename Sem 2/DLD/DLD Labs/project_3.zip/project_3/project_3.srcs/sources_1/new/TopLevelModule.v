`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 03/21/2025 03:36:00 PM
// Design Name: 
// Module Name: TopLevelModule
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module TopLevelModule(
    input clk,
    output [9:0] h_count,
    output [9:0] v_count
); 
    wire clk_d;
    wire trig_v;
    clk_div_org div1 (clk, clk_d);
    h_counter h1 (h_count,trig_v,clk_d);
    v_counter v1(clk_d,trig_v,v_count);
    
endmodule
