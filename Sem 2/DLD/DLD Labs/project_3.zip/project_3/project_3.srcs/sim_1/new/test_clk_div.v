module test_clk_div;

    reg clk;
    wire clk_d;

    // Instantiate the clock divider module
    clk_div test_func (
        .clk(clk),
        .clk_d(clk_d)
    );

    // Clock generation (100MHz -> 10ns period)
    always #5 clk = ~clk; 

    initial begin
        clk = 0;
        #1000; // Run simulation for a sufficient duration
        $stop;
    end

endmodule
