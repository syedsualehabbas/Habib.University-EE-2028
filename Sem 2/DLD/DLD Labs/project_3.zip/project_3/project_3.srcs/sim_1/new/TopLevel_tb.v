`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 03/21/2025
// Design Name: 
// Module Name: TopLevelModule_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// Testbench for TopLevelModule
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module TopLevelModule_tb;

    // Inputs
    reg clk;

    // Outputs
    wire [9:0] h_count;
    wire [9:0] v_count;

    // Instantiate the Unit Under Test (UUT)
    TopLevelModule uut (
        .clk(clk),
        .h_count(h_count),
        .v_count(v_count)
    );

    // Generate a clock signal with a period of 10ns (100MHz)
    initial begin
        clk = 0;
        forever #0.2 clk = ~clk; // Toggle clk every 5ns for a 10ns period
    end

    // Stimulus process to test the behavior of the module

endmodule
