`timescale 1ns / 1ps

module test_v_counter();
    reg clk;
    reg v_enable;
    wire [9:0] v_count;

    v_counter c1 (.clk(clk), .v_enable(v_enable), .v_count(v_count));

    // Generate clock with 5 ns period (100 MHz clock)
    initial clk = 1'b0;
    always #5 clk = ~clk;  

    // Stimulus for the vertical counter (v_enable toggles)
    initial begin
        // Initial state: enable the counter
        v_enable = 1;
        
        // Change enable signal at different time intervals
        #100 v_enable = 0;      // Disable for 100 ns
        #100 v_enable = 1;      // Re-enable for 100 ns
        #15000 $finish;         // End simulation after 16,000 ns
    end

    // Optionally, print the v_count value at each clock cycle for debugging
endmodule
