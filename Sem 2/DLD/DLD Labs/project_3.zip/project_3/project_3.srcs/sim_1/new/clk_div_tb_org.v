module clk_div_tb_org();

    reg clk;
    wire clk_d;

    // Instantiate clock divider module
    clk_div_org uut (
        .clk(clk),
        .clk_d(clk_d)
    );

    // Generate clock (100MHz -> 10ns period)
    initial
    clk=1'b0;
    always
    #0.2 clk=~clk;
endmodule
