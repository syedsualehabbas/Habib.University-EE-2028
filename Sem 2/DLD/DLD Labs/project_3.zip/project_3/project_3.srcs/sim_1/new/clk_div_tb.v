module clk_div_tb;

    reg clk;
    wire clk_d;

    // Instantiate clock divider module
    clk_div uut (
        .clk(clk),
        .clk_d(clk_d)
    );

    // Generate clock (100MHz -> 10ns period)
    always #5 clk = ~clk;

    initial begin
        clk = 0;
        #1000;
        $stop;
    end

endmodule
