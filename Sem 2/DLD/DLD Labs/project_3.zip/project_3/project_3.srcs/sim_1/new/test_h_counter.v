module test_h_counter();
    reg clk;
    wire [9:0] count;
    wire v_trig;
    // Instantiate the counter module
    h_counter c1 (.clk(clk), .count(count), .trig_v(v_trig));

    // Initialize clock
    initial clk = 1'b0;

    // Generate clock signal with a period of 10 time units (T = 10, so toggle every 5 units)
    always #0.5 clk = ~clk;

    // Stop simulation after 200 time units
    initial #1000 $finish;
endmodule
